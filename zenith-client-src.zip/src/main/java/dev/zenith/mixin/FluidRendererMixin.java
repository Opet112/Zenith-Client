package dev.zenith.mixin;

import dev.zenith.module.impl.Xray;
import net.minecraft.block.BlockState;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.block.FluidRenderer;
import net.minecraft.fluid.FluidState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockRenderView;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(FluidRenderer.class)
public abstract class FluidRendererMixin {
    /** Xray: hide water (and lava unless "Show lava" is on). */
    @Inject(method = "render", at = @At("HEAD"), cancellable = true, require = 0)
    private void zenith$xrayFluids(BlockRenderView world, BlockPos pos, VertexConsumer consumer, BlockState blockState, FluidState fluidState, CallbackInfo ci) {
        if (Xray.active() && !Xray.isWhitelisted(fluidState.getBlockState().getBlock())) ci.cancel();
    }
}
