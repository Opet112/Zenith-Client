package dev.zenith.mixin;

import dev.zenith.module.impl.NoPush;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {
    @Inject(method = "pushAway", at = @At("HEAD"), cancellable = true, require = 0)
    private void zenith$noPush(Entity other, CallbackInfo ci) {
        if (NoPush.blocksEntities((Entity) (Object) this)) ci.cancel();
    }
}
