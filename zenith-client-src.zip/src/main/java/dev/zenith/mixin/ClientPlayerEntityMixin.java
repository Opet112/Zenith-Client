package dev.zenith.mixin;

import dev.zenith.module.impl.NoSlow;
import dev.zenith.util.RotationManager;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerEntity.class)
public abstract class ClientPlayerEntityMixin {
    /** Silent rotations: the movement packets are built with the server-side rotation, then the camera is restored. */
    @Inject(method = "sendMovementPackets", at = @At("HEAD"), require = 0)
    private void zenith$rotationBefore(CallbackInfo ci) {
        RotationManager.beforeSend((ClientPlayerEntity) (Object) this);
    }

    @Inject(method = "sendMovementPackets", at = @At("RETURN"), require = 0)
    private void zenith$rotationAfter(CallbackInfo ci) {
        RotationManager.afterSend((ClientPlayerEntity) (Object) this);
    }

    /** NoSlow: pretend you are not using an item when the movement slowdown is computed. */
    @Redirect(method = "tickMovement",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/network/ClientPlayerEntity;isUsingItem()Z"),
            require = 0)
    private boolean zenith$noSlow(ClientPlayerEntity self) {
        return !NoSlow.active() && self.isUsingItem();
    }
}
