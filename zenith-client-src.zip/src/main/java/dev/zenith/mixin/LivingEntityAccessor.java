package dev.zenith.mixin;

import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(LivingEntity.class)
public interface LivingEntityAccessor {
    @Accessor("jumpingCooldown")
    int zenith$getJumpingCooldown();

    @Accessor("jumpingCooldown")
    void zenith$setJumpingCooldown(int value);
}
