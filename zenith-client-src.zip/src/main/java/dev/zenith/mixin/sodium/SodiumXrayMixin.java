package dev.zenith.mixin.sodium;

import dev.zenith.module.impl.Xray;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.Direction;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Sodium has its own face culling, so Xray needs the same decision there. Only loaded when Sodium is installed. */
@Mixin(targets = "net.caffeinemc.mods.sodium.client.render.model.AbstractBlockRenderContext", remap = false)
public abstract class SodiumXrayMixin {
    @Shadow protected BlockState state;

    @Inject(method = "shouldDrawSide", at = @At("HEAD"), cancellable = true, require = 0)
    private void zenith$xray(Direction facing, CallbackInfoReturnable<Boolean> cir) {
        if (Xray.active()) cir.setReturnValue(Xray.shouldDraw(state));
    }
}
