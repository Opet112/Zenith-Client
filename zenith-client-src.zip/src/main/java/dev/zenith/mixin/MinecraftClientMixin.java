package dev.zenith.mixin;

import dev.zenith.module.impl.Timer;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(MinecraftClient.class)
public abstract class MinecraftClientMixin {
    /** Timer: shorten/lengthen the time one game tick takes. */
    @Inject(method = "getTargetMillisPerTick", at = @At("RETURN"), cancellable = true, require = 0)
    private void zenith$timer(float millis, CallbackInfoReturnable<Float> cir) {
        double speed = Timer.speed();
        if (speed != 1.0) cir.setReturnValue(cir.getReturnValueF() / (float) speed);
    }
}
