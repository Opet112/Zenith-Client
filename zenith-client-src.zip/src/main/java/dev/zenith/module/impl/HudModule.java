package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;

public class HudModule extends Module {
    public final Setting.Mode theme = add(new Setting.Mode("Theme", "Storm", "Storm", "Rainbow", "Cyan", "Purple", "Crimson", "Emerald"));
    public final Setting.Bool watermark = add(new Setting.Bool("Watermark", true));
    public final Setting.Bool arrayList = add(new Setting.Bool("Array list", true));
    public final Setting.Bool coords = add(new Setting.Bool("Coordinates", true));
    public final Setting.Bool fps = add(new Setting.Bool("FPS", true));
    public final Setting.Bool speed = add(new Setting.Bool("Speed (b/s)", false));
    public final Setting.Bool ping = add(new Setting.Bool("Ping", false));
    public final Setting.Bool direction = add(new Setting.Bool("Direction", false));
    public final Setting.Bool cps = add(new Setting.Bool("CPS", false));
    public final Setting.Bool fovCorrection = add(new Setting.Bool("ESP FOV fix", true));
    public final Setting.Bool toggleMessages = add(new Setting.Bool("Toggle messages", true));

    /** Horizontal speed in blocks per second, smoothed. */
    public double bps;
    private double lastX, lastZ;
    private boolean hasLast;

    public HudModule() {
        super("HUD", "Watermark, module list and info overlay.", Category.CLIENT);
        visible = false;
        setEnabledSilently(true);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null) { hasLast = false; return; }
        if (hasLast) {
            double dx = p.getX() - lastX, dz = p.getZ() - lastZ;
            bps = bps * 0.7 + Math.sqrt(dx * dx + dz * dz) * 20.0 * 0.3;
        }
        lastX = p.getX();
        lastZ = p.getZ();
        hasLast = true;
    }
}
