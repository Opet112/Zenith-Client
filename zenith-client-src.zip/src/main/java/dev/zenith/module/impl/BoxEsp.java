package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.ColorUtil;
import dev.zenith.util.EntityUtil;

import dev.zenith.util.DrawUtil;
import dev.zenith.util.Projector;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.PlayerEntity;

public class BoxEsp extends Module {
    private final Setting.Num range = add(new Setting.Num("Range", 64, 8, 160, 4));
    private final Setting.Bool players = add(new Setting.Bool("Players", true));
    private final Setting.Bool hostiles = add(new Setting.Bool("Hostiles", true));
    private final Setting.Bool animals = add(new Setting.Bool("Animals", false));
    private final Setting.Bool health = add(new Setting.Bool("Health bar", true));

    public BoxEsp() {
        super("BoxESP", "Draws a box around entities, visible through walls.", Category.RENDER);
    }

    static int colorOf(Entity e) {
        if (e instanceof PlayerEntity) return EntityUtil.isFriend(e) ? 0xFF35D6E8 : 0xFFFF4D4D;
        if (e instanceof HostileEntity) return 0xFFFFB347;
        return 0xFF2FD27E;
    }

    static boolean wanted(Entity e, boolean pl, boolean ho, boolean an) {
        if (e instanceof ArmorStandEntity || !(e instanceof LivingEntity)) return false;
        if (e instanceof PlayerEntity) return pl;
        if (e instanceof HostileEntity) return ho;
        return an && e instanceof AnimalEntity;
    }

    @Override
    public void onRender(DrawContext ctx) {
        if (mc.world == null || mc.player == null) return;
        float partial = ZenithClient.partial();
        Projector pr = Projector.create(partial);
        if (pr == null) return;
        for (Entity e : mc.world.getEntities()) {
            if (e == mc.player || !wanted(e, players.get(), hostiles.get(), animals.get())) continue;
            if (mc.player.distanceTo(e) > range.get()) continue;
            double[] s = pr.box(Projector.lerpedBox(e, partial));
            if (s == null || s[2] - s[0] > pr.width * 2) continue;
            int x0 = (int) s[0], y0 = (int) s[1], x1 = (int) s[2], y1 = (int) s[3];
            DrawUtil.outline(ctx, x0, y0, x1, y1, colorOf(e));
            if (health.get() && e instanceof LivingEntity le) {
                float frac = Math.max(0f, Math.min(1f, le.getHealth() / Math.max(1f, le.getMaxHealth())));
                int top = y1 - (int) ((y1 - y0) * frac);
                ctx.fill(x0 - 3, y0, x0 - 1, y1 + 1, 0xFF1B1F27);
                ctx.fill(x0 - 3, top, x0 - 1, y1 + 1, frac > 0.6f ? 0xFF2FD27E : frac > 0.3f ? 0xFFFFB347 : 0xFFE8344F);
            }
        }
    }
}
