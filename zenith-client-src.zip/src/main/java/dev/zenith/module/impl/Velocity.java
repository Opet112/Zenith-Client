package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.ColorUtil;
import dev.zenith.util.EntityUtil;

import net.minecraft.util.math.Vec3d;

/** Scales knockback. The mixin captures your motion before the server packet and calls apply() afterwards. */
public class Velocity extends Module {
    private static Velocity instance;
    private static Vec3d before;

    private final Setting.Num horizontal = add(new Setting.Num("Horizontal %", 0, 0, 100, 5));
    private final Setting.Num vertical = add(new Setting.Num("Vertical %", 0, 0, 100, 5));
    private final Setting.Num chance = add(new Setting.Num("Chance %", 100, 0, 100, 5));

    public Velocity() {
        super("Velocity", "Reduces the knockback you take.", Category.COMBAT);
        instance = this;
    }

    public static void capture() {
        var p = mc.player;
        before = (instance != null && instance.isEnabled() && p != null) ? p.getVelocity() : null;
    }

    public static void apply() {
        var p = mc.player;
        if (before == null || instance == null || !instance.isEnabled() || p == null) { before = null; return; }
        Vec3d prev = before;
        before = null;
        if (Math.random() * 100.0 >= instance.chance.get()) return;
        Vec3d now = p.getVelocity();
        Vec3d delta = now.subtract(prev);
        double h = instance.horizontal.get() / 100.0, v = instance.vertical.get() / 100.0;
        p.setVelocity(prev.x + delta.x * h, prev.y + delta.y * v, prev.z + delta.z * h);
    }

    @Override
    public String getSuffix() { return (int) horizontal.get() + "% " + (int) vertical.get() + "%"; }
}
