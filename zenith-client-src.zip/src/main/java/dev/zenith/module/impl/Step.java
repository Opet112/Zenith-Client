package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.EntityUtil;

import net.minecraft.entity.attribute.EntityAttributes;

public class Step extends Module {
    private final Setting.Num height = add(new Setting.Num("Height", 1.5, 0.6, 5.0, 0.1));

    public Step() {
        super("Step", "Walk up blocks without jumping.", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        var attr = mc.player.getAttributeInstance(EntityAttributes.STEP_HEIGHT);
        if (attr != null && attr.getBaseValue() != height.get()) attr.setBaseValue(height.get());
    }

    @Override
    protected void onDisable() { reset(); }

    @Override
    public void onShutdown() { reset(); }

    private void reset() {
        if (mc.player == null) return;
        var attr = mc.player.getAttributeInstance(EntityAttributes.STEP_HEIGHT);
        if (attr != null) attr.setBaseValue(0.6);
    }
}
