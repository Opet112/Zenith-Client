package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.EntityUtil;

import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

public class NoFall extends Module {
    private final Setting.Num distance = add(new Setting.Num("Min distance", 2.5, 1.0, 10.0, 0.5));

    public NoFall() {
        super("NoFall", "Cancels fall damage by reporting that you are on the ground.", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.getNetworkHandler() == null) return;
        if (!p.isOnGround() && p.getVelocity().y < 0 && p.fallDistance > distance.get()) {
            mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.OnGroundOnly(true, p.horizontalCollision));
        }
    }
}
