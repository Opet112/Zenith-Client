package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.EntityUtil;

public class Eagle extends Module {
    private boolean forced;

    public Eagle() {
        super("Eagle", "Auto-sneaks at block edges so you never fall off.", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.currentScreen != null) return;
        boolean edge = EntityUtil.atEdge(p);
        if (edge) { mc.options.sneakKey.setPressed(true); forced = true; }
        else if (forced) { mc.options.sneakKey.setPressed(false); forced = false; }
    }

    @Override
    protected void onDisable() {
        if (forced) mc.options.sneakKey.setPressed(false);
        forced = false;
    }
}
