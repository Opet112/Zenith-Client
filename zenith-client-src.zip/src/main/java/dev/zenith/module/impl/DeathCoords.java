package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.EntityUtil;

import net.minecraft.client.gui.screen.DeathScreen;

public class DeathCoords extends Module {
    private boolean reported;

    public DeathCoords() {
        super("DeathCoords", "Prints the coordinates where you died.", Category.MISC);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null) return;
        if (mc.currentScreen instanceof DeathScreen) {
            if (!reported) {
                reported = true;
                ZenithClient.info("You died at §e" + p.getBlockX() + " " + p.getBlockY() + " " + p.getBlockZ());
            }
        } else {
            reported = false;
        }
    }
}
