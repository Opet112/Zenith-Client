package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import net.minecraft.client.gui.screen.DeathScreen;

public class AutoRespawn extends Module {
    public AutoRespawn() {
        super("AutoRespawn", "Respawns immediately after dying.", Category.PLAYER);
    }

    @Override
    public void onTick() {
        if (mc.player != null && mc.currentScreen instanceof DeathScreen) mc.player.requestRespawn();
    }
}
