package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.EntityUtil;

import net.minecraft.util.hit.EntityHitResult;

public class WTap extends Module {
    private boolean attackWas;

    public WTap() {
        super("WTap", "Resets your sprint on every hit for extra knockback.", Category.COMBAT);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null) return;
        boolean attack = mc.options.attackKey.isPressed();
        if (attack && !attackWas && p.isSprinting() && mc.crosshairTarget instanceof EntityHitResult) {
            p.setSprinting(false);
        }
        attackWas = attack;
    }
}
