package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.EntityUtil;

import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.screen.slot.SlotActionType;

public class AutoArmor extends Module {
    private static final String[] TYPES = {"helmet", "chestplate", "leggings", "boots"};
    private static final EquipmentSlot[] SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    private final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 3, 0, 20, 1));
    private int wait;

    public AutoArmor() {
        super("AutoArmor", "Equips the best armor from your inventory.", Category.COMBAT);
    }

    private static int score(ItemStack stack, String type) {
        if (stack.isEmpty()) return 0;
        String path = Registries.ITEM.getId(stack.getItem()).getPath();
        if (!path.endsWith("_" + type)) return -1;
        return EntityUtil.materialRank(path) * 10 + 1;
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (wait-- > 0) return;

        for (int t = 0; t < 4; t++) {
            ItemStack worn = p.getEquippedStack(SLOTS[t]);
            int wornScore = score(worn, TYPES[t]);
            if (wornScore < 0) wornScore = 0;
            int bestSlot = -1, bestScore = wornScore;
            for (int i = 0; i < 36; i++) {
                int sc = score(p.getInventory().getStack(i), TYPES[t]);
                if (sc > bestScore) { bestScore = sc; bestSlot = i; }
            }
            if (bestSlot < 0) continue;
            int syncId = p.playerScreenHandler.syncId;
            if (!worn.isEmpty()) {
                // take the worse piece off first; the better one is equipped on a following tick
                mc.interactionManager.clickSlot(syncId, 5 + t, 0, SlotActionType.QUICK_MOVE, p);
            } else {
                int slot = bestSlot < 9 ? 36 + bestSlot : bestSlot;
                mc.interactionManager.clickSlot(syncId, slot, 0, SlotActionType.QUICK_MOVE, p);
            }
            wait = delay.getInt();
            return;
        }
    }
}
