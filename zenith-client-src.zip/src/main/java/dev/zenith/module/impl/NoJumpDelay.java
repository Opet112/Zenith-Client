package dev.zenith.module.impl;

import dev.zenith.ZenithClient;
import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.ColorUtil;
import dev.zenith.util.EntityUtil;

import dev.zenith.mixin.LivingEntityAccessor;

public class NoJumpDelay extends Module {
    public NoJumpDelay() {
        super("NoJumpDelay", "Jump again the moment you land.", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        if (mc.player != null) ((LivingEntityAccessor) (Object) mc.player).zenith$setJumpingCooldown(0);
    }
}
