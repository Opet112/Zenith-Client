package dev.zenith.module.impl;

import dev.zenith.module.Category;
import dev.zenith.module.Module;
import dev.zenith.setting.Setting;
import dev.zenith.util.ColorUtil;
import dev.zenith.util.EntityUtil;

import net.minecraft.entity.projectile.FishingBobberEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

public class AutoFish extends Module {
    private final Setting.Num recast = add(new Setting.Num("Recast delay", 20, 5, 60, 1));
    private int sinceCast;
    private int recastWait = -1;

    public AutoFish() {
        super("AutoFish", "Reels in and recasts automatically (hold a fishing rod).", Category.PLAYER);
    }

    @Override
    protected void onEnable() { sinceCast = 0; recastWait = -1; }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.interactionManager == null || !p.getMainHandStack().isOf(Items.FISHING_ROD)) return;

        if (recastWait >= 0) {
            if (recastWait-- == 0) {
                mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
                sinceCast = 0;
            }
            return;
        }
        FishingBobberEntity bobber = p.fishHook;
        if (bobber == null) return;
        sinceCast++;
        // A bite pulls the bobber sharply downwards while it sits in water.
        if (sinceCast > 40 && bobber.isTouchingWater() && bobber.getVelocity().y < -0.04) {
            mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
            recastWait = recast.getInt();
        }
    }
}
