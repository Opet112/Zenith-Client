package dev.zenith.util;

import net.minecraft.client.gui.DrawContext;

public final class DrawUtil {
    private DrawUtil() {}

    public static void line(DrawContext ctx, double x0, double y0, double x1, double y1, int color, int w, int h) {
        double dx = x1 - x0, dy = y1 - y0;
        int steps = (int) Math.max(Math.abs(dx), Math.abs(dy));
        if (steps <= 0 || steps > 6000) return;
        double sx = dx / steps, sy = dy / steps;
        double x = x0, y = y0;
        for (int i = 0; i <= steps; i++) {
            if (x >= 0 && y >= 0 && x < w && y < h) ctx.fill((int) x, (int) y, (int) x + 1, (int) y + 1, color);
            x += sx;
            y += sy;
        }
    }

    public static void outline(DrawContext ctx, int x0, int y0, int x1, int y1, int color) {
        ctx.fill(x0, y0, x1 + 1, y0 + 1, color);
        ctx.fill(x0, y1, x1 + 1, y1 + 1, color);
        ctx.fill(x0, y0, x0 + 1, y1 + 1, color);
        ctx.fill(x1, y0, x1 + 1, y1 + 1, color);
    }
}
